/* global QUnit */

sap.ui.require(["masterindirectos/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});

sap.ui.define([
	"masterindirectos/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
